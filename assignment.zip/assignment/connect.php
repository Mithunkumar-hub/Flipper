<?php

// data save from  friend.txt file
extract($_REQUEST);
$file = fopen ("friend.txt","a");

fwrite($file,"FIRST_FRIEND=");
fwrite($file,$first ."\n\n");
fwrite($file,"SECOND_FRIEND=");
fwrite($file,$second ."\n\n");
fwrite($file,"THIRD_FRIEND=");
fwrite($file,$third ."\n\n");
fclose($file);
// redirect page
header("refresh:0;url=index.html");
?>