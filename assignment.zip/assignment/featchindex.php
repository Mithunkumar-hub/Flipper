<?php
$connection = mysqli_connect("localhost","root","");
$db = mysqli_select_db($connection,'friend');

if(isset($_POST['search_post_btn']))
{
    $id = $_POST['id'];
    $query="select * from friend where id ='$id'";
    $query_run= mysqli_query($connection,$query);
    if($query_run)
    {
        while($row = mysqli_fetch_array($query_run))
        {
       
            ?>
            <input type="text" name="first"  class="output_box" placholder="Friend name here" value="<?php echo $row['first'] ?>"><br>
            <input type="text" name="second"  class="output_box" placholder="Friend name here" value="<?php echo $row['second'] ?>"><br>
            <input type="text" name="third"  class="output_box" placholder="Friend name here" value="<?php echo $row['third'] ?>"><br>
            <input type="submit" name="SUBMIT" id="btn" value="save friend list" >
           
            <?php
        
        }

    }
    else{
        
    }

}

?>
